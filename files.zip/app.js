/* ============================================
   SISTECOSTOS — app.js
   Lógica completa del sistema
   ============================================ */


// ── USUARIOS ──
const USERS = {
  admin:     { pass: "12345",  nombre: "Josue" },
  itzy:      { pass: "itzy1",  nombre: "Itzy" },
  alejandra: { pass: "ale1",   nombre: "Alejandra" },
  david:     { pass: "david1", nombre: "David" },
  dulce:     { pass: "dulce1", nombre: "Dulce" },
};

function doLogin() {
  const user = document.getElementById("login-user").value.trim().toLowerCase();
  const pass = document.getElementById("login-pass").value;
  const err  = document.getElementById("login-error");
  if (!USERS[user] || USERS[user].pass !== pass) {
    err.textContent = "Usuario o contraseña incorrectos.";
    document.getElementById("login-pass").value = "";
    document.getElementById("login-pass").focus();
    return;
  }
  err.textContent = "";
  const nombre = USERS[user].nombre;
  document.getElementById("brand-welcome").textContent = "Bienvenido " + nombre;
  document.getElementById("login-overlay").style.display = "none";
  document.getElementById("app-shell").style.display = "block";
  sessionStorage.setItem("sc_user", user);
  sessionStorage.setItem("sc_nombre", nombre);
}

function doLogout() {
  sessionStorage.removeItem("sc_user");
  sessionStorage.removeItem("sc_nombre");
  document.getElementById("app-shell").style.display = "none";
  document.getElementById("login-overlay").style.display = "flex";
  document.getElementById("login-user").value = "";
  document.getElementById("login-pass").value = "";
  document.getElementById("login-error").textContent = "";
}

function togglePass() {
  const inp = document.getElementById("login-pass");
  inp.type = inp.type === "password" ? "text" : "password";
}

// ── ESTADO GLOBAL ──
const state = {
  empresa: null,
  materiales: [],
  trabajadores: [],
  cifItems: []
};

// ── LOCALSTORAGE ──
const LS_KEY = 'sistecostos_v1';

function saveState() {
  try {
    localStorage.setItem(LS_KEY, JSON.stringify(state));
  } catch (e) {
    console.warn('No se pudo guardar en localStorage:', e);
  }
}

function loadState() {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (!raw) return;
    const saved = JSON.parse(raw);
    if (saved.empresa)      state.empresa      = saved.empresa;
    if (saved.materiales)   state.materiales   = saved.materiales;
    if (saved.trabajadores) state.trabajadores = saved.trabajadores;
    if (saved.cifItems)     state.cifItems     = saved.cifItems;
  } catch (e) {
    console.warn('No se pudo leer localStorage:', e);
  }
}

function clearAllData() {
  if (!confirm('¿Seguro que quieres borrar todos los datos? Esta acción no se puede deshacer.')) return;
  localStorage.removeItem(LS_KEY);
  state.empresa = null;
  state.materiales = [];
  state.trabajadores = [];
  state.cifItems = [];
  // Limpiar campos de empresa
  ['emp-nombre','emp-giro','emp-producto','emp-area','emp-periodo','emp-unidades','emp-problema','emp-objetivo']
    .forEach(id => { const el = document.getElementById(id); if (el) el.value = ''; });
  renderInventario();
  renderNomina();
  renderCIF();
  updateDashboard();
  toast('Datos borrados correctamente.');
}

// ── UTILIDADES ──
function fmt(n) {
  const num = parseFloat(n) || 0;
  return 'C$ ' + num.toLocaleString('es-NI', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
}

function fmtNum(n) {
  return (parseFloat(n) || 0).toLocaleString('es-NI', { minimumFractionDigits: 0, maximumFractionDigits: 0 });
}

function pct(part, total) {
  if (!total) return '0%';
  return ((part / total) * 100).toFixed(1) + '%';
}

function toast(msg, type = 'ok') {
  const t = document.getElementById('toast');
  t.textContent = (type === 'ok' ? '✓ ' : '⚠ ') + msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2800);
}

function clearInputs(ids) {
  ids.forEach(id => {
    const el = document.getElementById(id);
    if (el) el.value = '';
  });
}

// ── NAVEGACIÓN ──
function showPage(name) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.tnav').forEach(n => n.classList.remove('active'));
  document.querySelectorAll('.bnav').forEach(n => n.classList.remove('active'));

  const page = document.getElementById('page-' + name);
  if (page) page.classList.add('active');

  const labels = {
    dashboard:  'Panel general',
    empresa:    'Empresa',
    inventario: 'Inventario de materiales',
    nomina:     'Nómina de producción',
    cif:        'CIF — Costos indirectos',
    reporte:    'Reporte de costo de producción',
    flujo:      'Flujo del sistema'
  };
  document.getElementById('breadcrumb').textContent = labels[name] || name;

  // Activar enlace correcto en ambas navs
  const order = ['dashboard','empresa','inventario','nomina','cif','reporte','flujo'];
  const idx = order.indexOf(name);
  const tnavItems = document.querySelectorAll('.tnav');
  const bnavItems = document.querySelectorAll('.bnav');
  if (idx >= 0) {
    if (tnavItems[idx]) tnavItems[idx].classList.add('active');
    if (bnavItems[idx]) bnavItems[idx].classList.add('active');
  }

  updateDashboard();
  window.scrollTo(0, 0);
}



// ── DASHBOARD ──
function updateDashboard() {
  const md = state.materiales.filter(m => m.tipo === 'Directo').reduce((a, m) => a + m.total, 0);
  const mi = state.materiales.filter(m => m.tipo === 'Indirecto').reduce((a, m) => a + m.total, 0);
  const mod = state.trabajadores.filter(t => t.clasif === 'MOD').reduce((a, t) => a + t.bruto, 0);
  const moi = state.trabajadores.filter(t => t.clasif === 'MOI').reduce((a, t) => a + t.bruto, 0);
  const cifExtra = state.cifItems.reduce((a, c) => a + c.monto, 0);
  const totalCIF = mi + moi + cifExtra;
  const cTotal = md + mod + totalCIF;
  const unidades = state.empresa ? parseInt(state.empresa.unidades) || 0 : 0;
  const cUnit = unidades > 0 ? cTotal / unidades : 0;

  document.getElementById('dash-md').textContent = fmt(md);
  document.getElementById('dash-mod').textContent = fmt(mod);
  document.getElementById('dash-cif').textContent = fmt(totalCIF);
  document.getElementById('dash-total').textContent = fmt(cTotal);
  document.getElementById('dash-md-items').textContent = state.materiales.filter(m => m.tipo === 'Directo').length + ' mat. directos';
  document.getElementById('dash-mod-items').textContent = state.trabajadores.filter(t => t.clasif === 'MOD').length + ' trabajadores MOD';
  document.getElementById('dash-cif-items').textContent = state.cifItems.length + ' conceptos adicionales';
  document.getElementById('dash-unit').textContent = 'Costo unit.: ' + fmt(cUnit);

  // Alert
  const alert = document.getElementById('dash-alert');
  if (state.empresa) alert.style.display = 'none';
  else alert.style.display = 'flex';

  // Status módulos
  updateModuleStatus('status-empresa', 'status-empresa-detail',
    state.empresa != null,
    state.empresa ? state.empresa.nombre : 'Sin configurar',
    false);

  updateModuleStatus('status-inv', 'status-inv-detail',
    state.materiales.length > 0,
    state.materiales.length + ' materiales registrados',
    false);

  updateModuleStatus('status-nom', 'status-nom-detail',
    state.trabajadores.length > 0,
    state.trabajadores.length + ' trabajadores registrados',
    false);

  updateModuleStatus('status-cif', 'status-cif-detail',
    state.cifItems.length > 0 || mi > 0 || moi > 0,
    state.cifItems.length + ' conceptos adicionales' + (mi + moi > 0 ? ' + auto desde módulos' : ''),
    false);
}

function updateModuleStatus(cardId, detailId, ok, detail, partial) {
  const card = document.getElementById(cardId);
  if (!card) return;
  const dot = card.querySelector('.status-dot');
  const badge = card.querySelector('.status-badge');
  const detailEl = document.getElementById(detailId);
  if (detailEl) detailEl.textContent = detail;
  if (ok) {
    dot.className = 'status-dot dot-ok';
    badge.className = 'status-badge badge-ok';
    badge.textContent = 'Listo';
  } else {
    dot.className = 'status-dot dot-pending';
    badge.className = 'status-badge badge-pending';
    badge.textContent = 'Pendiente';
  }
}

// ── EMPRESA ──
function guardarEmpresa() {
  const nombre   = document.getElementById('emp-nombre').value.trim();
  const giro     = document.getElementById('emp-giro').value.trim();
  const producto = document.getElementById('emp-producto').value.trim();
  const area     = document.getElementById('emp-area').value.trim();
  const periodo  = document.getElementById('emp-periodo').value.trim();
  const unidades = document.getElementById('emp-unidades').value.trim();
  const problema = document.getElementById('emp-problema').value.trim();
  const objetivo = document.getElementById('emp-objetivo').value.trim();

  if (!nombre || !producto) {
    toast('Completa al menos el nombre de la empresa y el producto.', 'warn');
    return;
  }

  state.empresa = { nombre, giro, producto, area, periodo, unidades, problema, objetivo };
  saveState();
  toast('Empresa guardada correctamente.');
  updateDashboard();

  // Prefill reporte
  if (periodo) document.getElementById('rep-periodo').value = periodo;
  if (unidades) document.getElementById('rep-unidades').value = unidades;
}

// ── INVENTARIO ──
function addMaterial() {
  const codigo    = document.getElementById('inv-codigo').value.trim();
  const nombre    = document.getElementById('inv-nombre').value.trim();
  const tipo      = document.getElementById('inv-tipo').value;
  const unidad    = document.getElementById('inv-unidad').value.trim();
  const disponible= parseFloat(document.getElementById('inv-disponible').value) || 0;
  const cantidad  = parseFloat(document.getElementById('inv-cantidad').value) || 0;
  const costoUnit = parseFloat(document.getElementById('inv-costounit').value) || 0;

  if (!nombre) { toast('El nombre del material es obligatorio.', 'warn'); return; }
  if (cantidad <= 0) { toast('La cantidad consumida debe ser mayor a cero.', 'warn'); return; }
  if (costoUnit <= 0) { toast('El costo unitario debe ser mayor a cero.', 'warn'); return; }

  const total = cantidad * costoUnit;
  state.materiales.push({ id: Date.now(), codigo, nombre, tipo, unidad, disponible, cantidad, costoUnit, total });

  clearInputs(['inv-codigo','inv-nombre','inv-unidad','inv-disponible','inv-cantidad','inv-costounit']);
  renderInventario();
  updateDashboard();
  saveState();
  toast('Material "' + nombre + '" registrado.');
}

function delMaterial(id) {
  state.materiales = state.materiales.filter(m => m.id !== id);
  renderInventario();
  updateDashboard();
  saveState();
  toast('Material eliminado.');
}

function renderInventario() {
  const wrap = document.getElementById('inv-table-wrap');
  const md = state.materiales.filter(m => m.tipo === 'Directo').reduce((a, m) => a + m.total, 0);
  const mi = state.materiales.filter(m => m.tipo === 'Indirecto').reduce((a, m) => a + m.total, 0);

  document.getElementById('inv-total-md-mini').textContent = fmt(md);
  document.getElementById('inv-total-mi-mini').textContent = fmt(mi);

  if (state.materiales.length === 0) {
    wrap.innerHTML = '<div class="empty-state"><span class="empty-icon">◫</span>No hay materiales registrados</div>';
    return;
  }

  const rows = state.materiales.map(m => {
    const lotes    = m.pepsLotes || [];
    const pepsCalc = lotes.length > 0 ? calcPeps(lotes) : null;

    // Tabla PEPS
    const pepsRows = pepsCalc ? pepsCalc.rows.map(r => `
      <tr>
        <td>${r.fecha}</td>
        <td><span class="${r.clase}">${r.tipo}</span></td>
        <td class="num">${fmtNum(r.cant)} ${m.unidad}</td>
        <td class="num">${fmt(r.costo)}</td>
        <td class="num">${fmt(r.total)}</td>
      </tr>
    `).join('') : '';

    const pepsPanel = `
      <div class="peps-panel" id="peps-${m.id}">
        <div class="peps-panel-title">Tarjeta PEPS — ${m.nombre}</div>
        <div class="peps-form form-grid cols-3" style="margin-bottom:14px;">
          <div class="form-group"><label>Fecha</label><input type="date" id="peps-fecha-${m.id}"></div>
          <div class="form-group"><label>Tipo</label><select id="peps-tipo-${m.id}"><option value="Entrada">Entrada</option><option value="Salida">Salida</option></select></div>
          <div class="form-group"><label>Cantidad</label><input type="number" id="peps-cant-${m.id}" min="0" step="any" placeholder="0"></div>
          <div class="form-group"><label>Costo unitario (C$)</label><input type="number" id="peps-costo-${m.id}" min="0" step="any" placeholder="0"></div>
        </div>
        <button class="btn-primary" style="font-size:12px; padding:7px 14px; margin-bottom:14px;" onclick="addLotePeps(${m.id})">+ Agregar lote</button>
        ${lotes.length > 0 ? `
          <div class="peps-table-wrap">
            <table>
              <thead><tr><th>Fecha</th><th>Tipo</th><th class="num">Cantidad</th><th class="num">Costo unit.</th><th class="num">Total</th></tr></thead>
              <tbody>
                ${pepsRows}
                <tr class="total-row">
                  <td colspan="2">Saldo en existencia</td>
                  <td class="num peps-saldo">${fmtNum(pepsCalc.saldoCant)} ${m.unidad}</td>
                  <td></td>
                  <td class="num peps-saldo">${fmt(pepsCalc.saldoCosto)}</td>
                </tr>
              </tbody>
            </table>
          </div>
          <div class="peps-result">
            <span class="peps-result-label">Costo material usado (PEPS)</span>
            <span class="peps-result-value">${fmt(pepsCalc.costoUsado)}</span>
          </div>
        ` : '<div style="font-size:12px; color:var(--text3); padding:8px 0;">Agrega entradas y salidas para ver el kardex PEPS.</div>'}
      </div>
    `;

    return `
      <tr>
        <td>${m.codigo || '—'}</td>
        <td>${m.nombre}</td>
        <td><span class="pill ${m.tipo === 'Directo' ? 'pill-blue' : 'pill-orange'}">${m.tipo}</span></td>
        <td>${fmtNum(m.disponible)} ${m.unidad}</td>
        <td>${fmtNum(m.cantidad)} ${m.unidad}</td>
        <td class="num">${fmt(m.costoUnit)}</td>
        <td class="num"><strong>${fmt(m.total)}</strong></td>
        <td>
          <button class="peps-toggle" onclick="togglePeps(${m.id})">PEPS</button>
        </td>
        <td><button class="btn-danger" onclick="delMaterial(${m.id})" title="Eliminar">✕</button></td>
      </tr>
      <tr>
        <td colspan="9" style="padding:0; border-bottom: 1px solid var(--border);">
          ${pepsPanel}
        </td>
      </tr>
    `;
  }).join('');

  wrap.innerHTML = `
    <div class="table-responsive">
      <table>
        <thead>
          <tr>
            <th>Código</th><th>Material</th><th>Tipo</th>
            <th>Disponible</th><th>Consumido</th>
            <th class="num">Costo unit.</th><th class="num">Costo total</th>
            <th>PEPS</th><th></th>
          </tr>
        </thead>
        <tbody>
          ${rows}
          <tr class="total-row">
            <td colspan="6">Total material directo consumido</td>
            <td class="num">${fmt(md)}</td><td></td><td></td>
          </tr>
        </tbody>
      </table>
    </div>
  `;
}

// ── NÓMINA ──
// ── CÁLCULO AUTOMÁTICO INSS / IR (Nicaragua) ──
const INSS_LABORAL_PCT   = 0.07;   // 7% sobre ingresos brutos
const INSS_PATRONAL_PCT  = 0.225;  // 22.5% sobre salario bruto
const INATEC_PCT         = 0.02;   // 2% sobre salario bruto
const VACACIONES_PCT     = 0.0833; // 8.33% (1 mes / 12)
const AGUINALDO_PCT      = 0.0833; // 8.33% (1 mes / 12)
const IR_EXENTO_ANUAL    = 200000; // C$200,000 exentos al año (C$16,666.67 mensual)

function calcInss(bruto) {
  return bruto * INSS_LABORAL_PCT;
}

// Tabla progresiva de IR (renta del trabajo) sobre base imponible MENSUAL.
// Exento anual C$200,000 (C$16,666.67/mes), tramos progresivos sobre el excedente
// según la estructura vigente de la Ley de Concertación Tributaria.
function calcIR(brutoMensual, inssMensual) {
  const baseImponible = brutoMensual - inssMensual;
  const baseAnual = baseImponible * 12;

  let irAnual = 0;
  if (baseAnual <= IR_EXENTO_ANUAL) {
    irAnual = 0;
  } else if (baseAnual <= 350000) {
    irAnual = (baseAnual - IR_EXENTO_ANUAL) * 0.15;
  } else if (baseAnual <= 500000) {
    irAnual = 22500 + (baseAnual - 350000) * 0.20;
  } else if (baseAnual <= 1000000) {
    irAnual = 52500 + (baseAnual - 500000) * 0.25;
  } else {
    irAnual = 177500 + (baseAnual - 1000000) * 0.30;
  }
  return irAnual / 12;
}

// Devuelve todos los cálculos derivados de los valores actuales del formulario / trabajador
function calcNomina({ salario, antiguedad, bonos, jornada, he, factorHE, otras }) {
  const valorHoraOrd = jornada > 0 ? (salario / 30) / jornada : 0;
  const pagoHE  = he * valorHoraOrd * factorHE;
  const bruto   = salario + antiguedad + bonos + pagoHE;
  const inss    = calcInss(bruto);
  const ir      = calcIR(bruto, inss);
  const deducciones = inss + ir + otras;
  const neto    = bruto - deducciones;

  // Cargas patronales y provisiones (sobre el salario bruto del trabajador)
  const inssPatronal = bruto * INSS_PATRONAL_PCT;
  const inatec        = bruto * INATEC_PCT;
  const vacaciones    = bruto * VACACIONES_PCT;
  const aguinaldo      = bruto * AGUINALDO_PCT;

  return { valorHoraOrd, pagoHE, bruto, inss, ir, deducciones, neto, inssPatronal, inatec, vacaciones, aguinaldo };
}

function readNomFormValues() {
  return {
    salario:    parseFloat(document.getElementById('nom-salario').value) || 0,
    antiguedad: parseFloat(document.getElementById('nom-antiguedad').value) || 0,
    bonos:      parseFloat(document.getElementById('nom-bonos').value) || 0,
    jornada:    parseFloat(document.getElementById('nom-jornada').value) || 8,
    he:         parseFloat(document.getElementById('nom-he').value) || 0,
    factorHE:   parseFloat(document.getElementById('nom-factorhe').value) || 1.5,
    otras:      parseFloat(document.getElementById('nom-otras').value) || 0
  };
}

function previewDeducciones() {
  const vals = readNomFormValues();
  const c = calcNomina(vals);

  document.getElementById('nom-valhora-display').textContent   = fmt(c.valorHoraOrd);
  document.getElementById('nom-pagohe-display').textContent    = fmt(c.pagoHE);
  document.getElementById('nom-bruto-display').textContent     = fmt(c.bruto);
  document.getElementById('nom-inss-display').textContent      = fmt(c.inss);
  document.getElementById('nom-ir-display').textContent        = fmt(c.ir);
  document.getElementById('nom-deduc-total-preview').textContent = fmt(c.neto);
}

function addTrabajador() {
  const nombre  = document.getElementById('nom-nombre').value.trim();
  const cargo   = document.getElementById('nom-cargo').value.trim();
  const area    = document.getElementById('nom-area').value.trim();
  const clasif  = document.getElementById('nom-clasif').value;
  const vals    = readNomFormValues();

  if (!nombre) { toast('El nombre del trabajador es obligatorio.', 'warn'); return; }
  if (vals.salario <= 0) { toast('El salario base debe ser mayor a cero.', 'warn'); return; }

  const c = calcNomina(vals);

  state.trabajadores.push({
    id: Date.now(), nombre, cargo, area, clasif,
    salario: vals.salario, antiguedad: vals.antiguedad, bonos: vals.bonos,
    jornada: vals.jornada, he: vals.he, factorHE: vals.factorHE,
    valorHoraOrd: c.valorHoraOrd, pagoHE: c.pagoHE,
    bruto: c.bruto, inss: c.inss, ir: c.ir, otras: vals.otras,
    deducciones: c.deducciones, neto: c.neto,
    inssPatronal: c.inssPatronal, inatec: c.inatec,
    vacaciones: c.vacaciones, aguinaldo: c.aguinaldo
  });

  clearInputs(['nom-nombre','nom-cargo','nom-area','nom-salario','nom-antiguedad','nom-bonos','nom-he','nom-otras']);
  document.getElementById('nom-jornada').value = 8;
  document.getElementById('nom-valhora-display').textContent = 'C$ 0';
  document.getElementById('nom-pagohe-display').textContent  = 'C$ 0';
  document.getElementById('nom-bruto-display').textContent   = 'C$ 0';
  document.getElementById('nom-inss-display').textContent    = 'C$ 0';
  document.getElementById('nom-ir-display').textContent      = 'C$ 0';
  document.getElementById('nom-deduc-total-preview').textContent = 'C$ 0';
  renderNomina();
  updateDashboard();
  saveState();
  toast('Trabajador "' + nombre + '" registrado.');
}


function delTrabajador(id) {
  state.trabajadores = state.trabajadores.filter(t => t.id !== id);
  renderNomina();
  updateDashboard();
  saveState();
  toast('Trabajador eliminado.');
}

// Departamento contable según clasificación (para asiento de diario)
function deptoDe(clasif) {
  if (clasif === 'MOD' || clasif === 'MOI') return 'Producción / Costos';
  if (clasif === 'Gasto administrativo') return 'Administración';
  if (clasif === 'Gasto de venta') return 'Ventas';
  return 'Otros';
}

function renderNomina() {
  const wrap = document.getElementById('nom-table-wrap');
  const mod = state.trabajadores.filter(t => t.clasif === 'MOD').reduce((a, t) => a + t.bruto, 0);
  const moi = state.trabajadores.filter(t => t.clasif === 'MOI').reduce((a, t) => a + t.bruto, 0);

  document.getElementById('nom-total-mod-mini').textContent = fmt(mod);
  document.getElementById('nom-total-moi-mini').textContent = fmt(moi);

  renderPatronal();
  renderAsiento();

  if (state.trabajadores.length === 0) {
    wrap.innerHTML = '<div class="empty-state"><div class="empty-icon">◉</div><div>No hay trabajadores registrados</div></div>';
    return;
  }

  const clasifPill = {
    'MOD': 'pill-green',
    'MOI': 'pill-orange',
    'Gasto administrativo': 'pill-gray',
    'Gasto de venta': 'pill-purple'
  };

  const totBruto = state.trabajadores.reduce((a, t) => a + t.bruto, 0);
  const totInss  = state.trabajadores.reduce((a, t) => a + t.inss, 0);
  const totIr    = state.trabajadores.reduce((a, t) => a + t.ir, 0);
  const totDeduc = state.trabajadores.reduce((a, t) => a + t.deducciones, 0);
  const totNeto  = state.trabajadores.reduce((a, t) => a + t.neto, 0);

  const rows = state.trabajadores.map(t => `
    <tr>
      <td>${t.nombre}</td>
      <td>${t.cargo || '—'}</td>
      <td class="num">${fmt(t.salario)}</td>
      <td class="num">${t.antiguedad > 0 ? fmt(t.antiguedad) : '—'}</td>
      <td class="num">${t.pagoHE > 0 ? fmt(t.pagoHE) : '—'}</td>
      <td class="num"><strong>${fmt(t.bruto)}</strong></td>
      <td class="num">${fmt(t.inss)}</td>
      <td class="num">${fmt(t.ir)}</td>
      <td class="num">${fmt(t.deducciones)}</td>
      <td class="num"><strong>${fmt(t.neto)}</strong></td>
      <td><span class="pill ${clasifPill[t.clasif] || 'pill-gray'}">${t.clasif}</span></td>
      <td><button class="btn-danger" onclick="delTrabajador(${t.id})" title="Eliminar">✕</button></td>
    </tr>
  `).join('');

  wrap.innerHTML = `
    <div class="table-responsive">
      <table>
        <thead>
          <tr>
            <th>Nombre</th>
            <th>Cargo</th>
            <th class="num">Salario base</th>
            <th class="num">Antigüedad</th>
            <th class="num">Horas extras</th>
            <th class="num">Ingresos brutos</th>
            <th class="num">INSS laboral</th>
            <th class="num">IR laboral</th>
            <th class="num">Total deducciones</th>
            <th class="num">Salario neto</th>
            <th>Clasificación</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          ${rows}
          <tr class="total-row">
            <td colspan="2">TOTALES</td>
            <td class="num"></td>
            <td class="num"></td>
            <td class="num"></td>
            <td class="num">${fmt(totBruto)}</td>
            <td class="num">${fmt(totInss)}</td>
            <td class="num">${fmt(totIr)}</td>
            <td class="num">${fmt(totDeduc)}</td>
            <td class="num">${fmt(totNeto)}</td>
            <td></td><td></td>
          </tr>
          <tr class="total-row">
            <td colspan="5">Total mano de obra directa (MOD)</td>
            <td class="num">${fmt(mod)}</td>
            <td colspan="5"></td>
          </tr>
          <tr class="total-row">
            <td colspan="5">Total mano de obra indirecta (MOI)</td>
            <td class="num">${fmt(moi)}</td>
            <td colspan="5"></td>
          </tr>
        </tbody>
      </table>
    </div>
  `;
}

// ── CUADRO RESUMEN DE OBLIGACIONES PATRONALES ──
function renderPatronal() {
  const wrap = document.getElementById('nom-patronal-wrap');
  if (!wrap) return;
  if (state.trabajadores.length === 0) {
    wrap.innerHTML = '<div class="empty-state"><span class="empty-icon">◈</span>Registra trabajadores para calcular las cargas patronales</div>';
    return;
  }

  const totBruto      = state.trabajadores.reduce((a, t) => a + t.bruto, 0);
  const totInssPat    = state.trabajadores.reduce((a, t) => a + t.inssPatronal, 0);
  const totInatec     = state.trabajadores.reduce((a, t) => a + t.inatec, 0);
  const totVacaciones = state.trabajadores.reduce((a, t) => a + t.vacaciones, 0);
  const totAguinaldo  = state.trabajadores.reduce((a, t) => a + t.aguinaldo, 0);
  const totProvisiones = totVacaciones + totAguinaldo;
  const totCargaPatronal = totInssPat + totInatec;
  const totCostoLaboral  = totBruto + totCargaPatronal + totProvisiones;

  wrap.innerHTML = `
    <div class="table-responsive">
      <table>
        <thead>
          <tr>
            <th>Concepto</th>
            <th class="num">Base de cálculo</th>
            <th class="num">% aplicado</th>
            <th class="num">Total a pagar</th>
          </tr>
        </thead>
        <tbody>
          <tr><td>INSS Patronal</td><td class="num">${fmt(totBruto)}</td><td class="num">22.5%</td><td class="num"><strong>${fmt(totInssPat)}</strong></td></tr>
          <tr><td>INATEC</td><td class="num">${fmt(totBruto)}</td><td class="num">2%</td><td class="num"><strong>${fmt(totInatec)}</strong></td></tr>
          <tr class="total-row"><td>Total cargas patronales (INSS + INATEC)</td><td></td><td></td><td class="num"><strong>${fmt(totCargaPatronal)}</strong></td></tr>
          <tr><td>Provisión Vacaciones</td><td class="num">${fmt(totBruto)}</td><td class="num">8.33%</td><td class="num">${fmt(totVacaciones)}</td></tr>
          <tr><td>Provisión Treceavo mes (Aguinaldo)</td><td class="num">${fmt(totBruto)}</td><td class="num">8.33%</td><td class="num">${fmt(totAguinaldo)}</td></tr>
          <tr class="total-row"><td>Total provisiones / prestaciones sociales</td><td></td><td></td><td class="num"><strong>${fmt(totProvisiones)}</strong></td></tr>
          <tr class="total-row"><td colspan="3">COSTO LABORAL TOTAL (Bruto + cargas + provisiones)</td><td class="num"><strong>${fmt(totCostoLaboral)}</strong></td></tr>
        </tbody>
      </table>
    </div>
  `;
}

// ── DISTRIBUCIÓN CONTABLE — ASIENTO DE DIARIO ──
function renderAsiento() {
  const wrap = document.getElementById('nom-asiento-wrap');
  if (!wrap) return;
  if (state.trabajadores.length === 0) {
    wrap.innerHTML = '<div class="empty-state"><span class="empty-icon">▤</span>Registra trabajadores para generar el asiento contable</div>';
    return;
  }

  const deptos = ['Producción / Costos', 'Administración', 'Ventas'];
  const porDepto = {};
  deptos.forEach(d => porDepto[d] = { bruto: 0, inssPatronal: 0, inatec: 0, vacaciones: 0, aguinaldo: 0 });

  state.trabajadores.forEach(t => {
    const d = deptoDe(t.clasif);
    if (!porDepto[d]) porDepto[d] = { bruto: 0, inssPatronal: 0, inatec: 0, vacaciones: 0, aguinaldo: 0 };
    porDepto[d].bruto        += t.bruto;
    porDepto[d].inssPatronal += t.inssPatronal;
    porDepto[d].inatec       += t.inatec;
    porDepto[d].vacaciones   += t.vacaciones;
    porDepto[d].aguinaldo    += t.aguinaldo;
  });

  const cuentaGasto = {
    'Producción / Costos': 'Costos de producción — Mano de obra',
    'Administración': 'Gastos de administración — Sueldos y salarios',
    'Ventas': 'Gastos de venta — Sueldos y salarios',
    'Otros': 'Otros gastos de personal'
  };

  const totInss   = state.trabajadores.reduce((a, t) => a + t.inss, 0);
  const totIr     = state.trabajadores.reduce((a, t) => a + t.ir, 0);
  const totOtras  = state.trabajadores.reduce((a, t) => a + t.otras, 0);
  const totNeto   = state.trabajadores.reduce((a, t) => a + t.neto, 0);
  const totBruto  = state.trabajadores.reduce((a, t) => a + t.bruto, 0);
  const totInssPat = state.trabajadores.reduce((a, t) => a + t.inssPatronal, 0);
  const totInatec   = state.trabajadores.reduce((a, t) => a + t.inatec, 0);
  const totVac      = state.trabajadores.reduce((a, t) => a + t.vacaciones, 0);
  const totAgui     = state.trabajadores.reduce((a, t) => a + t.aguinaldo, 0);

  let rowsHtml = '';
  let totalDebe = 0, totalHaber = 0;

  // 1) Registro de salarios devengados por departamento (DEBE)
  Object.keys(porDepto).forEach(d => {
    const v = porDepto[d];
    if (v.bruto <= 0) return;
    rowsHtml += `<tr><td>${cuentaGasto[d] || d}</td><td class="num">${fmt(v.bruto)}</td><td class="num">—</td></tr>`;
    totalDebe += v.bruto;
  });
  // 1b) Cargas patronales por departamento (DEBE)
  Object.keys(porDepto).forEach(d => {
    const v = porDepto[d];
    const carga = v.inssPatronal + v.inatec;
    if (carga <= 0) return;
    rowsHtml += `<tr><td>${cuentaGasto[d] || d} — Cargas patronales (INSS 22.5% + INATEC 2%)</td><td class="num">${fmt(carga)}</td><td class="num">—</td></tr>`;
    totalDebe += carga;
  });
  // 1c) Provisiones por departamento (DEBE)
  Object.keys(porDepto).forEach(d => {
    const v = porDepto[d];
    const prov = v.vacaciones + v.aguinaldo;
    if (prov <= 0) return;
    rowsHtml += `<tr><td>${cuentaGasto[d] || d} — Provisión vacaciones y treceavo mes</td><td class="num">${fmt(prov)}</td><td class="num">—</td></tr>`;
    totalDebe += prov;
  });

  // 2) Créditos (HABER)
  const haberRows = [
    ['Salarios por pagar (neto a empleados)', totNeto],
    ['INSS por pagar (laboral 7% + patronal 22.5%)', totInss + totInssPat],
    ['IR por pagar (retención laboral)', totIr],
    ['INATEC por pagar (2%)', totInatec],
    ['Vacaciones por pagar (provisión)', totVac],
    ['Aguinaldo / Treceavo mes por pagar (provisión)', totAgui]
  ];
  if (totOtras > 0) haberRows.push(['Otras deducciones por pagar', totOtras]);

  haberRows.forEach(([cuenta, monto]) => {
    if (monto <= 0) return;
    rowsHtml += `<tr><td>${cuenta}</td><td class="num">—</td><td class="num">${fmt(monto)}</td></tr>`;
    totalHaber += monto;
  });

  wrap.innerHTML = `
    <div class="table-responsive">
      <table>
        <thead>
          <tr><th>Cuenta</th><th class="num">Debe</th><th class="num">Haber</th></tr>
        </thead>
        <tbody>
          ${rowsHtml}
          <tr class="total-row"><td>TOTALES</td><td class="num">${fmt(totalDebe)}</td><td class="num">${fmt(totalHaber)}</td></tr>
        </tbody>
      </table>
    </div>
    <p style="font-size:12px;color:var(--text2);margin-top:8px;">
      El gasto/costo y las cargas patronales se distribuyen según la clasificación contable de cada trabajador:
      MOD y MOI → Producción/Costos, Gasto administrativo → Administración, Gasto de venta → Ventas.
    </p>
  `;
}


// ── CIF ──
function addCIF() {
  const concepto = document.getElementById('cif-concepto').value.trim();
  const tipo     = document.getElementById('cif-tipo').value;
  const comp     = document.getElementById('cif-comp').value;
  const monto    = parseFloat(document.getElementById('cif-monto').value) || 0;
  const area     = document.getElementById('cif-area').value.trim();
  const obs      = document.getElementById('cif-obs').value.trim();

  if (!concepto) { toast('El concepto CIF es obligatorio.', 'warn'); return; }
  if (monto <= 0) { toast('El monto debe ser mayor a cero.', 'warn'); return; }

  state.cifItems.push({ id: Date.now(), concepto, tipo, comp, monto, area, obs });

  clearInputs(['cif-concepto','cif-monto','cif-area','cif-obs']);
  renderCIF();
  updateDashboard();
  saveState();
  toast('CIF "' + concepto + '" registrado.');
}

function delCIF(id) {
  state.cifItems = state.cifItems.filter(c => c.id !== id);
  renderCIF();
  updateDashboard();
  saveState();
  toast('CIF eliminado.');
}

function renderCIF() {
  const wrap = document.getElementById('cif-table-wrap');
  const total = state.cifItems.reduce((a, c) => a + c.monto, 0);
  document.getElementById('cif-total-mini').textContent = fmt(total);

  if (state.cifItems.length === 0) {
    wrap.innerHTML = '<div class="empty-state"><div class="empty-icon">◈</div><div>No hay CIF adicionales registrados</div></div>';
    return;
  }

  const compPill = { 'Fijo': 'pill-gray', 'Variable': 'pill-blue', 'Mixto': 'pill-purple' };
  const tipoPill = {
    'Material indirecto': 'pill-orange',
    'Mano de obra indirecta': 'pill-green',
    'Otro CIF': 'pill-gray'
  };

  const rows = state.cifItems.map(c => `
    <tr>
      <td>${c.concepto}</td>
      <td><span class="pill ${tipoPill[c.tipo] || 'pill-gray'}">${c.tipo}</span></td>
      <td><span class="pill ${compPill[c.comp] || 'pill-gray'}">${c.comp}</span></td>
      <td class="num"><strong>${fmt(c.monto)}</strong></td>
      <td>${c.area || '—'}</td>
      <td>${c.obs || '—'}</td>
      <td><button class="btn-danger" onclick="delCIF(${c.id})" title="Eliminar">✕</button></td>
    </tr>
  `).join('');

  wrap.innerHTML = `
    <div class="table-responsive">
      <table>
        <thead>
          <tr>
            <th>Concepto</th>
            <th>Tipo de CIF</th>
            <th>Comportamiento</th>
            <th class="num">Monto</th>
            <th>Área</th>
            <th>Observación</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          ${rows}
          <tr class="total-row">
            <td colspan="3">Total CIF adicionales</td>
            <td class="num">${fmt(total)}</td>
            <td></td><td></td><td></td>
          </tr>
        </tbody>
      </table>
    </div>
  `;
}

// ── REPORTE ──
function generarReporte() {
  const periodo  = document.getElementById('rep-periodo').value.trim() || (state.empresa ? state.empresa.periodo : 'Período actual');
  const unidades = parseInt(document.getElementById('rep-unidades').value) || 0;

  if (unidades <= 0) { toast('Ingresa las unidades producidas.', 'warn'); return; }

  // Calcular totales
  const md  = state.materiales.filter(m => m.tipo === 'Directo').reduce((a, m) => a + m.total, 0);
  const mi  = state.materiales.filter(m => m.tipo === 'Indirecto').reduce((a, m) => a + m.total, 0);
  const mod = state.trabajadores.filter(t => t.clasif === 'MOD').reduce((a, t) => a + t.bruto, 0);
  const moi = state.trabajadores.filter(t => t.clasif === 'MOI').reduce((a, t) => a + t.bruto, 0);
  const cifExtra = state.cifItems.reduce((a, c) => a + c.monto, 0);

  const cifMI   = mi + state.cifItems.filter(c => c.tipo === 'Material indirecto').reduce((a, c) => a + c.monto, 0);
  const cifMOI  = moi + state.cifItems.filter(c => c.tipo === 'Mano de obra indirecta').reduce((a, c) => a + c.monto, 0);
  const cifOtros = state.cifItems.filter(c => c.tipo === 'Otro CIF').reduce((a, c) => a + c.monto, 0);
  const totalCIF = mi + moi + cifExtra;
  const cTotal   = md + mod + totalCIF;
  const cUnit    = cTotal / unidades;

  const empresa = state.empresa ? state.empresa.nombre : 'Mi empresa';
  const producto = state.empresa ? state.empresa.producto : '';

  // Porcentajes
  const pctMD  = cTotal > 0 ? ((md / cTotal) * 100).toFixed(1) : 0;
  const pctMOD = cTotal > 0 ? ((mod / cTotal) * 100).toFixed(1) : 0;
  const pctCIF = cTotal > 0 ? ((totalCIF / cTotal) * 100).toFixed(1) : 0;

  // Nómina detalle para reporte
  const nomRows = state.trabajadores.length > 0 ? state.trabajadores.map(t => `
    <tr>
      <td>${t.nombre}</td>
      <td>${t.cargo || '—'}</td>
      <td class="num">${fmt(t.salario)}</td>
      <td class="num">${t.pagoHE > 0 ? fmt(t.pagoHE) : '—'}</td>
      <td class="num">${fmt(t.bruto)}</td>
      <td class="num">${t.deducciones > 0 ? fmt(t.deducciones) : '—'}</td>
      <td><span class="pill ${t.clasif === 'MOD' ? 'pill-green' : 'pill-orange'}">${t.clasif}</span></td>
    </tr>
  `).join('') : '<tr><td colspan="7" class="empty-state" style="padding:14px;">Sin datos de nómina</td></tr>';

  // Inventario detalle
  const invRows = state.materiales.length > 0 ? state.materiales.map(m => `
    <tr>
      <td>${m.codigo || '—'}</td>
      <td>${m.nombre}</td>
      <td><span class="pill ${m.tipo === 'Directo' ? 'pill-blue' : 'pill-orange'}">${m.tipo}</span></td>
      <td>${fmtNum(m.cantidad)} ${m.unidad}</td>
      <td class="num">${fmt(m.costoUnit)}</td>
      <td class="num">${fmt(m.total)}</td>
    </tr>
  `).join('') : '<tr><td colspan="6" class="empty-state" style="padding:14px;">Sin datos de inventario</td></tr>';

  // CIF detalle
  const cifAutoRows = [];
  if (mi > 0) cifAutoRows.push(`<div class="cif-brow"><span>Materiales indirectos (inventario)</span><span>${fmt(mi)}</span></div>`);
  if (moi > 0) cifAutoRows.push(`<div class="cif-brow"><span>Mano de obra indirecta (nómina)</span><span>${fmt(moi)}</span></div>`);
  state.cifItems.forEach(c => {
    cifAutoRows.push(`<div class="cif-brow"><span>${c.concepto} <span class="pill pill-gray" style="font-size:10px;">${c.comp}</span></span><span>${fmt(c.monto)}</span></div>`);
  });
  cifAutoRows.push(`<div class="cif-brow"><span>Total CIF</span><span>${fmt(totalCIF)}</span></div>`);

  const out = document.getElementById('reporte-output');
  out.innerHTML = `

    <!-- HEADER -->
    <div class="reporte-empresa">
      <div class="reporte-empresa-name">${empresa}</div>
      <div class="reporte-empresa-meta">${producto ? 'Producto: ' + producto + '  ·  ' : ''}Período: ${periodo}  ·  Unidades producidas: ${fmtNum(unidades)}</div>
    </div>

    <!-- KPI STRIP -->
    <div class="reporte-kpis">
      <div class="rep-kpi kpi-blue">
        <div class="rep-kpi-label">Material directo</div>
        <div class="rep-kpi-value">${fmt(md)}</div>
        <div class="rep-kpi-pct">${pctMD}% del costo total</div>
      </div>
      <div class="rep-kpi kpi-green">
        <div class="rep-kpi-label">Mano de obra directa</div>
        <div class="rep-kpi-value">${fmt(mod)}</div>
        <div class="rep-kpi-pct">${pctMOD}% del costo total</div>
      </div>
      <div class="rep-kpi kpi-orange">
        <div class="rep-kpi-label">CIF acumulado</div>
        <div class="rep-kpi-value">${fmt(totalCIF)}</div>
        <div class="rep-kpi-pct">${pctCIF}% del costo total</div>
      </div>
    </div>

    <!-- TABLA PRINCIPAL -->
    <div class="reporte-table-card">
      <div class="reporte-table-head">Resumen de elementos del costo</div>
      <div class="rep-row">
        <div class="rep-row-label">
          <div class="rep-row-icon ri-blue">◫</div>
          <div>
            <div>Material directo consumido</div>
            <div class="rep-row-meta">Origen: módulo de inventario — materiales directos</div>
          </div>
        </div>
        <div class="rep-row-value">${fmt(md)}</div>
      </div>
      <div class="rep-row">
        <div class="rep-row-label">
          <div class="rep-row-icon ri-green">◉</div>
          <div>
            <div>Mano de obra directa</div>
            <div class="rep-row-meta">Origen: módulo de nómina — trabajadores MOD</div>
          </div>
        </div>
        <div class="rep-row-value">${fmt(mod)}</div>
      </div>
      <div class="rep-row">
        <div class="rep-row-label">
          <div class="rep-row-icon ri-orange">◈</div>
          <div>
            <div>Costos indirectos de fabricación (CIF)</div>
            <div class="rep-row-meta">Mat. indirecto + MOI + Otros CIF</div>
          </div>
        </div>
        <div class="rep-row-value">${fmt(totalCIF)}</div>
      </div>
      <div class="rep-total-row">
        <div class="rep-total-label">Costo total de producción</div>
        <div class="rep-total-value">${fmt(cTotal)}</div>
      </div>
    </div>

    <!-- COSTO UNITARIO -->
    <div class="rep-unit-grid">
      <div class="rep-unit-card">
        <div class="rep-unit-label">Unidades producidas</div>
        <div class="rep-unit-value">${fmtNum(unidades)}</div>
        <div class="rep-unit-sub">${producto || 'unidades'}</div>
      </div>
      <div class="rep-unit-card">
        <div class="rep-unit-label">Costo unitario de producción</div>
        <div class="rep-unit-value">${fmt(cUnit)}</div>
        <div class="rep-unit-sub">por unidad producida</div>
      </div>
    </div>

    <!-- FORMULA -->
    <div class="rep-formula">
      MD + MOD + CIF = <strong>${fmt(md)} + ${fmt(mod)} + ${fmt(totalCIF)} = ${fmt(cTotal)}</strong>
      &nbsp;&nbsp;·&nbsp;&nbsp;
      Costo unitario = <strong>${fmt(cTotal)} ÷ ${fmtNum(unidades)} = ${fmt(cUnit)}</strong>
    </div>

    <!-- CIF DESGLOSE -->
    <div class="cif-breakdown">
      <div class="cif-breakdown-title">Desglose del CIF acumulado</div>
      ${cifAutoRows.join('')}
    </div>

    <!-- INVENTARIO DETALLE -->
    <div class="card" style="margin-bottom:18px;">
      <div class="card-head"><span class="card-title">Detalle — Inventario de materiales</span></div>
      <div class="table-responsive">
        <table>
          <thead>
            <tr>
              <th>Código</th><th>Material</th><th>Tipo</th><th>Cant. consumida</th>
              <th class="num">Costo unit.</th><th class="num">Costo total</th>
            </tr>
          </thead>
          <tbody>${invRows}</tbody>
        </table>
      </div>
    </div>

    <!-- NÓMINA DETALLE -->
    <div class="card" style="margin-bottom:18px;">
      <div class="card-head"><span class="card-title">Detalle — Nómina de producción</span></div>
      <div class="table-responsive">
        <table>
          <thead>
            <tr>
              <th>Trabajador</th><th>Cargo</th><th class="num">Sal. ordinario</th>
              <th class="num">Pago HE</th><th class="num">Sal. bruto</th>
              <th class="num">Deducciones</th><th>Clasificación</th>
            </tr>
          </thead>
          <tbody>${nomRows}</tbody>
        </table>
      </div>
    </div>

  `;
  toast('Reporte generado correctamente.');
}

// ── CARGAR EJEMPLO ──
function cargarEjemplo() {
  // Empresa
  state.empresa = {
    nombre: 'Muebles del Pacífico, S.A.',
    giro: 'Fabricación de muebles escolares',
    producto: 'Silla escolar',
    area: 'Taller de carpintería',
    periodo: 'Enero 2025',
    unidades: '100',
    problema: 'La empresa no cuenta con un sistema organizado para registrar los costos de producción. Los cálculos se realizan de forma manual y sin clasificación adecuada, lo que genera errores y dificulta la toma de decisiones.',
    objetivo: 'Diseñar un sistema básico que permita registrar, clasificar y calcular el costo de producción de sillas escolares, integrando los módulos de inventario, nómina y CIF.'
  };
  document.getElementById('emp-nombre').value   = state.empresa.nombre;
  document.getElementById('emp-giro').value     = state.empresa.giro;
  document.getElementById('emp-producto').value = state.empresa.producto;
  document.getElementById('emp-area').value     = state.empresa.area;
  document.getElementById('emp-periodo').value  = state.empresa.periodo;
  document.getElementById('emp-unidades').value = state.empresa.unidades;
  document.getElementById('emp-problema').value = state.empresa.problema;
  document.getElementById('emp-objetivo').value = state.empresa.objetivo;

  // Inventario
  state.materiales = [
    { id: 1, codigo: 'MD-001', nombre: 'Madera de pino', tipo: 'Directo', unidad: 'Tablas', disponible: 50, cantidad: 40, costoUnit: 250, total: 10000 },
    { id: 2, codigo: 'MI-001', nombre: 'Tornillos y pegamento', tipo: 'Indirecto', unidad: 'Lote', disponible: 2, cantidad: 1, costoUnit: 1500, total: 1500 }
  ];

  // Nómina
  state.trabajadores = [
    { id: 1, nombre: 'Juan Pérez', cargo: 'Operario', area: 'Producción', clasif: 'MOD',
      salario: 12000, antiguedad: 500, bonos: 0, jornada: 8, he: 10, factorHE: 1.5,
      valorHoraOrd: 50, pagoHE: 750, bruto: 13250, inss: 927.5, ir: 0, otras: 130,
      deducciones: 1057.5, neto: 12192.5,
      inssPatronal: 2981.25, inatec: 265, vacaciones: 1103.73, aguinaldo: 1103.73 },
    { id: 2, nombre: 'Ana Ruiz', cargo: 'Supervisora', area: 'Producción', clasif: 'MOI',
      salario: 8000, antiguedad: 0, bonos: 0, jornada: 8, he: 0, factorHE: 1.5,
      valorHoraOrd: 33.33, pagoHE: 0, bruto: 8000, inss: 560, ir: 0, otras: 80,
      deducciones: 640, neto: 7360,
      inssPatronal: 1800, inatec: 160, vacaciones: 666.4, aguinaldo: 666.4 }
  ];

  // CIF
  state.cifItems = [
    { id: 1, concepto: 'Energía eléctrica de planta', tipo: 'Otro CIF', comp: 'Mixto', monto: 3000, area: 'Producción', obs: 'Se utiliza para operar maquinaria' },
    { id: 2, concepto: 'Depreciación de maquinaria', tipo: 'Otro CIF', comp: 'Fijo', monto: 2500, area: 'Producción', obs: 'Depreciación lineal mensual' },
    { id: 3, concepto: 'Mantenimiento de maquinaria', tipo: 'Otro CIF', comp: 'Mixto', monto: 1000, area: 'Producción', obs: 'Mantenimiento preventivo' }
  ];

  renderInventario();
  renderNomina();
  renderCIF();
  updateDashboard();
  saveState();

  document.getElementById('rep-periodo').value = 'Enero 2025';
  document.getElementById('rep-unidades').value = '100';

  toast('Datos de Muebles del Pacífico cargados.');
}

// ── INIT ──
document.addEventListener("DOMContentLoaded", () => {
  // Verificar sesión activa
  const savedUser   = sessionStorage.getItem("sc_user");
  const savedNombre = sessionStorage.getItem("sc_nombre");
  if (savedUser && USERS[savedUser]) {
    document.getElementById("brand-welcome").textContent = "Bienvenido " + savedNombre;
    document.getElementById("login-overlay").style.display = "none";
    document.getElementById("app-shell").style.display = "block";
  } else {
    document.getElementById("login-user").focus();
  }

  loadState();

  if (state.empresa) {
    const e = state.empresa;
    ["nombre","giro","producto","area","periodo","unidades","problema","objetivo"].forEach(k => {
      const el = document.getElementById("emp-" + k);
      if (el && e[k]) el.value = e[k];
    });
    if (e.periodo)  document.getElementById("rep-periodo").value  = e.periodo;
    if (e.unidades) document.getElementById("rep-unidades").value = e.unidades;
  }

  renderInventario();
  renderNomina();
  renderCIF();
  showPage("dashboard");
  updateDashboard();
});

// ── PEPS ──
function togglePeps(id) {
  const panel = document.getElementById('peps-' + id);
  if (!panel) return;
  panel.classList.toggle('open');
}

function addLotePeps(matId) {
  const fecha   = document.getElementById('peps-fecha-' + matId).value.trim();
  const tipo    = document.getElementById('peps-tipo-' + matId).value;
  const cant    = parseFloat(document.getElementById('peps-cant-' + matId).value) || 0;
  const costo   = parseFloat(document.getElementById('peps-costo-' + matId).value) || 0;

  if (!fecha || cant <= 0) { toast('Completa fecha y cantidad.', 'warn'); return; }

  const mat = state.materiales.find(m => m.id === matId);
  if (!mat) return;
  if (!mat.pepsLotes) mat.pepsLotes = [];
  mat.pepsLotes.push({ id: Date.now(), fecha, tipo, cant, costo });

  document.getElementById('peps-fecha-' + matId).value = '';
  document.getElementById('peps-cant-' + matId).value  = '';
  document.getElementById('peps-costo-' + matId).value = '';

  saveState();
  renderInventario();
  // reopen panel
  setTimeout(() => {
    const p = document.getElementById('peps-' + matId);
    if (p) p.classList.add('open');
  }, 10);
  toast('Lote PEPS registrado.');
}

function delLotePeps(matId, loteId) {
  const mat = state.materiales.find(m => m.id === matId);
  if (!mat || !mat.pepsLotes) return;
  mat.pepsLotes = mat.pepsLotes.filter(l => l.id !== loteId);
  saveState();
  renderInventario();
  setTimeout(() => {
    const p = document.getElementById('peps-' + matId);
    if (p) p.classList.add('open');
  }, 10);
}

function calcPeps(lotes) {
  // Calcula tabla kardex PEPS: entradas primero salen primero
  // Retorna { rows, costoUsado, saldoCant, saldoCosto }
  const entradas = lotes.filter(l => l.tipo === 'Entrada').sort((a,b) => a.fecha.localeCompare(b.fecha));
  const salidas  = lotes.filter(l => l.tipo === 'Salida').sort((a,b) => a.fecha.localeCompare(b.fecha));

  // Cola PEPS
  let cola = entradas.map(e => ({ fecha: e.fecha, cant: e.cant, costo: e.costo, restante: e.cant }));
  let rows = [];
  let costoUsado = 0;

  // Registrar entradas
  entradas.forEach(e => {
    rows.push({ fecha: e.fecha, tipo: 'Entrada', cant: e.cant, costo: e.costo, total: e.cant * e.costo, clase: 'peps-lote-entrada' });
  });

  // Procesar salidas PEPS
  salidas.forEach(s => {
    let restaSalida = s.cant;
    let costoSalida = 0;
    for (let lote of cola) {
      if (restaSalida <= 0) break;
      const usar = Math.min(lote.restante, restaSalida);
      costoSalida += usar * lote.costo;
      costoUsado  += usar * lote.costo;
      lote.restante -= usar;
      restaSalida   -= usar;
    }
    cola = cola.filter(l => l.restante > 0);
    rows.push({ fecha: s.fecha, tipo: 'Salida', cant: s.cant, costo: costoSalida / s.cant, total: costoSalida, clase: 'peps-lote-salida' });
  });

  // Saldo
  const saldoCant  = cola.reduce((a, l) => a + l.restante, 0);
  const saldoCosto = cola.reduce((a, l) => a + l.restante * l.costo, 0);
  rows.sort((a, b) => a.fecha.localeCompare(b.fecha));

  return { rows, costoUsado, saldoCant, saldoCosto };
}

// ══════════════════════════════════════════
// EXPORTACIÓN A EXCEL (SheetJS)
// ══════════════════════════════════════════

function xlsxNum(n) { return parseFloat(n) || 0; }

// Estilos base reutilizables
const XS = {
  header: { font: { bold: true, color: { rgb: 'FFFFFF' }, sz: 11 }, fill: { fgColor: { rgb: '1A2A1C' } }, alignment: { horizontal: 'center' }, border: { bottom: { style: 'thin', color: { rgb: '4ECB8D' } } } },
  subheader: { font: { bold: true, sz: 10 }, fill: { fgColor: { rgb: '151C16' } }, alignment: { horizontal: 'left' } },
  total: { font: { bold: true, sz: 11, color: { rgb: '4ECB8D' } }, fill: { fgColor: { rgb: '151C16' } } },
  empresa: { font: { bold: true, sz: 13 }, fill: { fgColor: { rgb: '0C0F0D' } }, alignment: { horizontal: 'left' } },
  num: { numFmt: '"C$"#,##0' },
  numBold: { font: { bold: true }, numFmt: '"C$"#,##0' },
};

function applyStyles(ws, styleMap) {
  Object.entries(styleMap).forEach(([cell, style]) => {
    if (!ws[cell]) return;
    ws[cell].s = style;
  });
}

function setColWidths(ws, widths) {
  ws['!cols'] = widths.map(w => ({ wch: w }));
}

// ── EXPORTAR INVENTARIO ──
function exportInventario() {
  if (state.materiales.length === 0) { toast('No hay materiales para exportar.', 'warn'); return; }
  const empresa = state.empresa ? state.empresa.nombre : 'Empresa';

  const wb = XLSX.utils.book_new();

  // Hoja 1: Inventario general
  const rows = [
    [empresa],
    ['MÓDULO DE INVENTARIO — MATERIALES'],
    [],
    ['Código', 'Material', 'Tipo', 'Unidad', 'Cant. disponible', 'Cant. consumida', 'Costo unitario', 'Costo total'],
  ];
  state.materiales.forEach(m => {
    rows.push([m.codigo || '—', m.nombre, m.tipo, m.unidad, xlsxNum(m.disponible), xlsxNum(m.cantidad), xlsxNum(m.costoUnit), xlsxNum(m.total)]);
  });
  const md = state.materiales.filter(x => x.tipo === 'Directo').reduce((a, x) => a + x.total, 0);
  const mi = state.materiales.filter(x => x.tipo === 'Indirecto').reduce((a, x) => a + x.total, 0);
  rows.push([], ['', '', '', '', '', 'Total MD', '', xlsxNum(md)], ['', '', '', '', '', 'Total MI', '', xlsxNum(mi)], ['', '', '', '', '', 'TOTAL', '', xlsxNum(md + mi)]);

  const ws1 = XLSX.utils.aoa_to_sheet(rows);
  ws1['!merges'] = [{ s:{r:0,c:0}, e:{r:0,c:7} }, { s:{r:1,c:0}, e:{r:1,c:7} }];
  setColWidths(ws1, [10, 28, 12, 10, 16, 16, 16, 14]);
  XLSX.utils.book_append_sheet(wb, ws1, 'Inventario');

  // Hoja 2: PEPS por material (solo los que tienen lotes)
  const conPeps = state.materiales.filter(m => m.pepsLotes && m.pepsLotes.length > 0);
  if (conPeps.length > 0) {
    const rowsPeps = [['TARJETAS PEPS POR MATERIAL'], []];
    conPeps.forEach(m => {
      const calc = calcPeps(m.pepsLotes);
      rowsPeps.push([`Material: ${m.nombre} (${m.codigo || '—'})`]);
      rowsPeps.push(['Fecha', 'Tipo', 'Cantidad', 'Costo unit.', 'Total']);
      calc.rows.forEach(r => rowsPeps.push([r.fecha, r.tipo, xlsxNum(r.cant), xlsxNum(r.costo), xlsxNum(r.total)]));
      rowsPeps.push(['', 'Saldo existencia', xlsxNum(calc.saldoCant), '', xlsxNum(calc.saldoCosto)]);
      rowsPeps.push(['', 'COSTO USADO (PEPS)', '', '', xlsxNum(calc.costoUsado)]);
      rowsPeps.push([]);
    });
    const ws2 = XLSX.utils.aoa_to_sheet(rowsPeps);
    setColWidths(ws2, [14, 18, 14, 14, 14]);
    XLSX.utils.book_append_sheet(wb, ws2, 'PEPS');
  }

  XLSX.writeFile(wb, `Inventario_${empresa.replace(/[^a-zA-Z0-9]/g, '_')}.xlsx`);
  toast('Inventario exportado a Excel.');
}

// ── EXPORTAR NÓMINA ──
function exportNomina() {
  if (state.trabajadores.length === 0) { toast('No hay trabajadores para exportar.', 'warn'); return; }
  const empresa = state.empresa ? state.empresa.nombre : 'Empresa';

  const wb = XLSX.utils.book_new();

  // ── Hoja 1: Tabla de nómina general ──
  const rows = [
    [empresa],
    ['MÓDULO DE NÓMINA — TABLA DE NÓMINA GENERAL'],
    [],
    ['Nombre', 'Cargo', 'Salario base', 'Antigüedad', 'Bonos', 'Horas extra (pago)', 'Ingresos brutos', 'INSS laboral', 'IR laboral', 'Otras ded.', 'Total deducciones', 'Salario neto', 'Clasificación'],
  ];
  state.trabajadores.forEach(t => {
    rows.push([t.nombre, t.cargo, xlsxNum(t.salario), xlsxNum(t.antiguedad), xlsxNum(t.bonos), xlsxNum(t.pagoHE), xlsxNum(t.bruto), xlsxNum(t.inss), xlsxNum(t.ir), xlsxNum(t.otras), xlsxNum(t.deducciones), xlsxNum(t.neto), t.clasif]);
  });
  const mod = state.trabajadores.filter(t => t.clasif === 'MOD').reduce((a, t) => a + t.bruto, 0);
  const moi = state.trabajadores.filter(t => t.clasif === 'MOI').reduce((a, t) => a + t.bruto, 0);
  const totBruto = state.trabajadores.reduce((a, t) => a + t.bruto, 0);
  const totInss  = state.trabajadores.reduce((a, t) => a + t.inss, 0);
  const totIr    = state.trabajadores.reduce((a, t) => a + t.ir, 0);
  const totDeduc = state.trabajadores.reduce((a, t) => a + t.deducciones, 0);
  const totNeto  = state.trabajadores.reduce((a, t) => a + t.neto, 0);
  rows.push([], ['', '', '', '', '', 'TOTALES', xlsxNum(totBruto), xlsxNum(totInss), xlsxNum(totIr), '', xlsxNum(totDeduc), xlsxNum(totNeto), '']);
  rows.push(['', '', '', '', '', '', '', '', '', '', 'Total MOD (bruto)', xlsxNum(mod), '']);
  rows.push(['', '', '', '', '', '', '', '', '', '', 'Total MOI (bruto)', xlsxNum(moi), '']);

  const ws = XLSX.utils.aoa_to_sheet(rows);
  ws['!merges'] = [{ s:{r:0,c:0}, e:{r:0,c:12} }, { s:{r:1,c:0}, e:{r:1,c:12} }];
  setColWidths(ws, [22, 16, 12, 12, 10, 14, 14, 12, 12, 10, 16, 12, 18]);
  XLSX.utils.book_append_sheet(wb, ws, 'Nómina');

  // ── Hoja 2: Resumen de obligaciones patronales ──
  const totInssPat    = state.trabajadores.reduce((a, t) => a + t.inssPatronal, 0);
  const totInatec      = state.trabajadores.reduce((a, t) => a + t.inatec, 0);
  const totVacaciones  = state.trabajadores.reduce((a, t) => a + t.vacaciones, 0);
  const totAguinaldo   = state.trabajadores.reduce((a, t) => a + t.aguinaldo, 0);
  const totCargaPat    = totInssPat + totInatec;
  const totProvisiones = totVacaciones + totAguinaldo;

  const rowsPat = [
    [empresa],
    ['CUADRO RESUMEN DE OBLIGACIONES PATRONALES'],
    [],
    ['Concepto', 'Base de cálculo', '% aplicado', 'Total a pagar'],
    ['INSS Patronal', xlsxNum(totBruto), 0.225, xlsxNum(totInssPat)],
    ['INATEC', xlsxNum(totBruto), 0.02, xlsxNum(totInatec)],
    ['Total cargas patronales', '', '', xlsxNum(totCargaPat)],
    [],
    ['Provisión Vacaciones', xlsxNum(totBruto), 0.0833, xlsxNum(totVacaciones)],
    ['Provisión Treceavo mes (Aguinaldo)', xlsxNum(totBruto), 0.0833, xlsxNum(totAguinaldo)],
    ['Total provisiones / prestaciones sociales', '', '', xlsxNum(totProvisiones)],
    [],
    ['COSTO LABORAL TOTAL (Bruto + cargas + provisiones)', '', '', xlsxNum(totBruto + totCargaPat + totProvisiones)],
  ];
  const wsPat = XLSX.utils.aoa_to_sheet(rowsPat);
  wsPat['!merges'] = [{ s:{r:0,c:0}, e:{r:0,c:3} }, { s:{r:1,c:0}, e:{r:1,c:3} }];
  ['C5','C6','C9','C10'].forEach(cell => { if (wsPat[cell]) wsPat[cell].z = '0.0%'; });
  setColWidths(wsPat, [42, 16, 12, 16]);
  XLSX.utils.book_append_sheet(wb, wsPat, 'Obligaciones patronales');

  // ── Hoja 3: Distribución contable / asiento de diario ──
  const deptos = ['Producción / Costos', 'Administración', 'Ventas'];
  const porDepto = {};
  deptos.forEach(d => porDepto[d] = { bruto: 0, inssPatronal: 0, inatec: 0, vacaciones: 0, aguinaldo: 0 });
  state.trabajadores.forEach(t => {
    const d = deptoDe(t.clasif);
    if (!porDepto[d]) porDepto[d] = { bruto: 0, inssPatronal: 0, inatec: 0, vacaciones: 0, aguinaldo: 0 };
    porDepto[d].bruto        += t.bruto;
    porDepto[d].inssPatronal += t.inssPatronal;
    porDepto[d].inatec       += t.inatec;
    porDepto[d].vacaciones   += t.vacaciones;
    porDepto[d].aguinaldo    += t.aguinaldo;
  });
  const cuentaGasto = {
    'Producción / Costos': 'Costos de producción — Mano de obra',
    'Administración': 'Gastos de administración — Sueldos y salarios',
    'Ventas': 'Gastos de venta — Sueldos y salarios',
    'Otros': 'Otros gastos de personal'
  };
  const totOtras = state.trabajadores.reduce((a, t) => a + t.otras, 0);

  const rowsAsiento = [
    [empresa],
    ['DISTRIBUCIÓN CONTABLE — ASIENTO DE DIARIO (PLANILLA)'],
    [],
    ['Cuenta', 'Debe', 'Haber'],
  ];
  let totalDebe = 0, totalHaber = 0;
  Object.keys(porDepto).forEach(d => {
    const v = porDepto[d];
    if (v.bruto <= 0) return;
    rowsAsiento.push([cuentaGasto[d] || d, xlsxNum(v.bruto), '']);
    totalDebe += v.bruto;
  });
  Object.keys(porDepto).forEach(d => {
    const v = porDepto[d];
    const carga = v.inssPatronal + v.inatec;
    if (carga <= 0) return;
    rowsAsiento.push([`${cuentaGasto[d] || d} — Cargas patronales (INSS 22.5% + INATEC 2%)`, xlsxNum(carga), '']);
    totalDebe += carga;
  });
  Object.keys(porDepto).forEach(d => {
    const v = porDepto[d];
    const prov = v.vacaciones + v.aguinaldo;
    if (prov <= 0) return;
    rowsAsiento.push([`${cuentaGasto[d] || d} — Provisión vacaciones y treceavo mes`, xlsxNum(prov), '']);
    totalDebe += prov;
  });
  const haberRows = [
    ['Salarios por pagar (neto a empleados)', totNeto],
    ['INSS por pagar (laboral 7% + patronal 22.5%)', totInss + totInssPat],
    ['IR por pagar (retención laboral)', totIr],
    ['INATEC por pagar (2%)', totInatec],
    ['Vacaciones por pagar (provisión)', totVacaciones],
    ['Aguinaldo / Treceavo mes por pagar (provisión)', totAguinaldo]
  ];
  if (totOtras > 0) haberRows.push(['Otras deducciones por pagar', totOtras]);
  haberRows.forEach(([cuenta, monto]) => {
    if (monto <= 0) return;
    rowsAsiento.push([cuenta, '', xlsxNum(monto)]);
    totalHaber += monto;
  });
  rowsAsiento.push([], ['TOTALES', xlsxNum(totalDebe), xlsxNum(totalHaber)]);

  const wsAsi = XLSX.utils.aoa_to_sheet(rowsAsiento);
  wsAsi['!merges'] = [{ s:{r:0,c:0}, e:{r:0,c:2} }, { s:{r:1,c:0}, e:{r:1,c:2} }];
  setColWidths(wsAsi, [50, 16, 16]);
  XLSX.utils.book_append_sheet(wb, wsAsi, 'Asiento contable');

  XLSX.writeFile(wb, `Nomina_${empresa.replace(/[^a-zA-Z0-9]/g, '_')}.xlsx`);
  toast('Nómina exportada a Excel.');
}

// ── EXPORTAR CIF ──
function exportCIF() {
  const empresa = state.empresa ? state.empresa.nombre : 'Empresa';
  const mi  = state.materiales.filter(m => m.tipo === 'Indirecto').reduce((a, m) => a + m.total, 0);
  const moi = state.trabajadores.filter(t => t.clasif === 'MOI').reduce((a, t) => a + t.bruto, 0);

  const wb = XLSX.utils.book_new();
  const rows = [
    [empresa],
    ['MÓDULO DE CIF — COSTOS INDIRECTOS DE FABRICACIÓN'],
    [],
    ['Concepto', 'Tipo de CIF', 'Comportamiento', 'Área', 'Monto (C$)', 'Observación'],
  ];

  if (mi > 0) rows.push(['Materiales indirectos (inventario)', 'Material indirecto', 'Variable', 'Producción', xlsxNum(mi), 'Integrado desde módulo de inventario']);
  if (moi > 0) rows.push(['Mano de obra indirecta (nómina)', 'MOI', 'Fijo', 'Producción', xlsxNum(moi), 'Integrado desde módulo de nómina']);
  state.cifItems.forEach(c => rows.push([c.concepto, c.tipo, c.comp, c.area || '—', xlsxNum(c.monto), c.obs || '—']));

  const total = mi + moi + state.cifItems.reduce((a, c) => a + c.monto, 0);
  rows.push([], ['', '', '', 'TOTAL CIF', xlsxNum(total), '']);

  const ws = XLSX.utils.aoa_to_sheet(rows);
  ws['!merges'] = [{ s:{r:0,c:0}, e:{r:0,c:5} }, { s:{r:1,c:0}, e:{r:1,c:5} }];
  setColWidths(ws, [34, 22, 14, 16, 14, 28]);
  XLSX.utils.book_append_sheet(wb, ws, 'CIF');

  XLSX.writeFile(wb, `CIF_${empresa.replace(/[^a-zA-Z0-9]/g, '_')}.xlsx`);
  toast('CIF exportado a Excel.');
}

// ── EXPORTAR REPORTE COMPLETO ──
function exportReporte() {
  const empresa  = state.empresa ? state.empresa.nombre : 'Empresa';
  const producto = state.empresa ? state.empresa.producto : '';
  const periodo  = document.getElementById('rep-periodo').value || (state.empresa ? state.empresa.periodo : '');
  const unidades = parseInt(document.getElementById('rep-unidades').value) || parseInt(state.empresa?.unidades) || 0;

  const md    = state.materiales.filter(m => m.tipo === 'Directo').reduce((a, m) => a + m.total, 0);
  const mi    = state.materiales.filter(m => m.tipo === 'Indirecto').reduce((a, m) => a + m.total, 0);
  const mod   = state.trabajadores.filter(t => t.clasif === 'MOD').reduce((a, t) => a + t.bruto, 0);
  const moi   = state.trabajadores.filter(t => t.clasif === 'MOI').reduce((a, t) => a + t.bruto, 0);
  const cifEx = state.cifItems.reduce((a, c) => a + c.monto, 0);
  const totalCIF = mi + moi + cifEx;
  const cTotal   = md + mod + totalCIF;
  const cUnit    = unidades > 0 ? cTotal / unidades : 0;

  const wb = XLSX.utils.book_new();

  // ── Hoja 1: Resumen ejecutivo ──
  const rowsRes = [
    [empresa],
    ['REPORTE DE COSTO DE PRODUCCIÓN'],
    [`Producto: ${producto}  |  Período: ${periodo}  |  Unidades: ${unidades}`],
    [],
    ['ELEMENTO DEL COSTO', 'MONTO (C$)', '% DEL TOTAL'],
    ['Material directo consumido', xlsxNum(md), cTotal > 0 ? (md/cTotal) : 0],
    ['Mano de obra directa (MOD)', xlsxNum(mod), cTotal > 0 ? (mod/cTotal) : 0],
    ['Costos indirectos de fabricación (CIF)', xlsxNum(totalCIF), cTotal > 0 ? (totalCIF/cTotal) : 0],
    [],
    ['COSTO TOTAL DE PRODUCCIÓN', xlsxNum(cTotal), 1],
    [],
    ['Unidades producidas', xlsxNum(unidades), ''],
    ['COSTO UNITARIO', xlsxNum(cUnit), ''],
    [],
    ['Fórmula:', `MD (${fmtNum(md)}) + MOD (${fmtNum(mod)}) + CIF (${fmtNum(totalCIF)}) = C$ ${fmtNum(cTotal)}`, ''],
  ];
  const wsRes = XLSX.utils.aoa_to_sheet(rowsRes);
  wsRes['!merges'] = [{ s:{r:0,c:0}, e:{r:0,c:2} }, { s:{r:1,c:0}, e:{r:1,c:2} }, { s:{r:2,c:0}, e:{r:2,c:2} }];
  // Formato porcentaje en columna C
  ['C6','C7','C8','C10'].forEach(cell => { if (wsRes[cell]) wsRes[cell].z = '0.0%'; });
  setColWidths(wsRes, [38, 18, 14]);
  XLSX.utils.book_append_sheet(wb, wsRes, 'Resumen');

  // ── Hoja 2: Desglose CIF ──
  const rowsCIF = [
    ['DESGLOSE DE CIF'],
    [],
    ['Concepto', 'Tipo', 'Comportamiento', 'Monto'],
  ];
  if (mi > 0)  rowsCIF.push(['Materiales indirectos (inv.)', 'Mat. indirecto', 'Variable', xlsxNum(mi)]);
  if (moi > 0) rowsCIF.push(['Mano de obra indirecta (nom.)', 'MOI', 'Fijo', xlsxNum(moi)]);
  state.cifItems.forEach(c => rowsCIF.push([c.concepto, c.tipo, c.comp, xlsxNum(c.monto)]));
  rowsCIF.push([], ['', '', 'TOTAL CIF', xlsxNum(totalCIF)]);
  const wsCIF = XLSX.utils.aoa_to_sheet(rowsCIF);
  setColWidths(wsCIF, [34, 22, 16, 14]);
  XLSX.utils.book_append_sheet(wb, wsCIF, 'Desglose CIF');

  // ── Hoja 3: Inventario ──
  const rowsInv = [['INVENTARIO DE MATERIALES'], [], ['Código','Material','Tipo','Unidad','Cant. consumida','Costo unit.','Costo total']];
  state.materiales.forEach(m => rowsInv.push([m.codigo||'—', m.nombre, m.tipo, m.unidad, xlsxNum(m.cantidad), xlsxNum(m.costoUnit), xlsxNum(m.total)]));
  rowsInv.push([], ['','','','','Total MD','', xlsxNum(md)]);
  const wsInv = XLSX.utils.aoa_to_sheet(rowsInv);
  setColWidths(wsInv, [10,28,12,10,16,14,14]);
  XLSX.utils.book_append_sheet(wb, wsInv, 'Inventario');

  // ── Hoja 4: Nómina ──
  const rowsNom = [['NÓMINA DE PRODUCCIÓN'], [], ['Trabajador','Cargo','Sal. bruto','Deducciones','Sal. neto','Clasificación']];
  state.trabajadores.forEach(t => rowsNom.push([t.nombre, t.cargo, xlsxNum(t.bruto), xlsxNum(t.deducciones), xlsxNum(t.neto), t.clasif]));
  rowsNom.push([], ['','Total MOD', xlsxNum(mod),'','',''], ['','Total MOI', xlsxNum(moi),'','','']);
  const wsNom = XLSX.utils.aoa_to_sheet(rowsNom);
  setColWidths(wsNom, [24,16,14,14,14,18]);
  XLSX.utils.book_append_sheet(wb, wsNom, 'Nómina');

  XLSX.writeFile(wb, `Reporte_Costos_${empresa.replace(/[^a-zA-Z0-9]/g, '_')}.xlsx`);
  toast('Reporte completo exportado a Excel.');
}
